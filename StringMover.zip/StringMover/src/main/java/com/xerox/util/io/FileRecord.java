package com.xerox.util.io;

public class FileRecord
{
  public String fileName;
  public String originalfilePath;
  public String newFilePath;
  public FileRecord(String FileName, String OriginalFilePath, String NewFilePath)
  {
	  fileName = FileName;
	  originalfilePath = OriginalFilePath;
	  newFilePath = NewFilePath;
  }
}

